

class Cart {
    constructor() {
        this.cartKey = 'shoeslab_cart';
        this.loadCart();
    }

    loadCart() {
        const cartData = localStorage.getItem(this.cartKey);
        this.cart = cartData ? JSON.parse(cartData) : {};
        return this.cart;
    }

    saveCart() {
        localStorage.setItem(this.cartKey, JSON.stringify(this.cart));
        this.updateCartCount();
    }

    addItem(productId, size, color, quantity = 1) {
        const key = `${productId}_${size}_${color}`;
        
        if (this.cart[key]) {
            this.cart[key].quantity += quantity;
        } else {
            this.cart[key] = {
                productId,
                size,
                color,
                quantity
            };
        }
        
        this.saveCart();
        return this.cart[key];
    }

    updateQuantity(key, quantity) {
        if (quantity <= 0) {
            delete this.cart[key];
        } else {
            this.cart[key].quantity = quantity;
        }
        this.saveCart();
    }

    removeItem(key) {
        delete this.cart[key];
        this.saveCart();
    }

    getItemsCount() {
        return Object.values(this.cart).reduce((sum, item) => sum + item.quantity, 0);
    }

    getTotalValue(products) {
        return Object.values(this.cart).reduce((total, item) => {
            const product = products.find(p => p.id === item.productId);
            return total + (product ? product.price * item.quantity : 0);
        }, 0);
    }

    getCartItems(products) {
        return Object.values(this.cart).map(item => ({
            ...item,
            product: products.find(p => p.id === item.productId)
        }));
    }

    updateCartCount() {
        const count = this.getItemsCount();
        const badge = document.getElementById('cart-badge');
        if (badge) {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'inline-flex' : 'none';
        }
    }

    clearCart() {
        this.cart = {};
        this.saveCart();
    }
}

const cart = new Cart();
