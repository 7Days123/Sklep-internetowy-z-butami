function renderProducts(productsList, category) {
    const grid = document.getElementById('products-grid');
    
    grid.innerHTML = '';
    
    let filtered;
    
    if (category === 'search') {
        filtered = productsList;
    } else {
        filtered = category === 'all' 
            ? productsList 
            : productsList.filter(p => p.category === category);
    }
    
    if (filtered.length === 0) {
        grid.innerHTML = `
            <div class="no-results">
                <h3>Brak wyników</h3>
                <p>Spróbuj inne hasło wyszukiwania lub kategorię.</p>
                <a href="index.html" class="btn-primary">Wyczyść i wróć</a>
            </div>
        `;
        return;
    }
}

const products = [

    {
        id: 1, name: "Adidas Stan Smith", brand: "Adidas", category: "damskie", type: "sportowe",
        price: 399.99, image: "https://via.placeholder.com/400x300/ffffff/000000?text=Adidas+Stan+Smith",
        colors: ["biały", "czarny", "różowy"], sizes: [36, 37, 38, 39, 40], description: "Klasyczne sneakersy z perforowaną cholewką.", stock: 15
    },
    {
        id: 2, name: "New Balance 574", brand: "New Balance", category: "damskie", type: "sportowe",
        price: 449.00, image: "https://via.placeholder.com/400x300/4a90e2/ffffff?text=NB+574", 
        colors: ["szary", "biały", "granatowy"], sizes: [36, 37, 38, 39], description: "Ikoniczne sneakersy retro z amortyzacją ENCAP.", stock: 12
    },
    {
        id: 3, name: "Nike Air Force 1", brand: "Nike", category: "damskie", type: "sportowe",
        price: 479.99, image: "https://via.placeholder.com/400x300/f7f7f7/000000?text=Nike+AF1",
        colors: ["biały", "czarny", "lilowy"], sizes: [36, 37, 38, 39, 40], description: "Kultowe sneakersy z poduszką Air.", stock: 18
    },
    {
        id: 4, name: "Puma Cali", brand: "Puma", category: "damskie", type: "sportowe",
        price: 359.99, image: "https://via.placeholder.com/400x300/ff6b6b/ffffff?text=Puma+Cali",
        colors: ["różowy", "biały", "czarny"], sizes: [37, 38, 39], description: "Platform sneakersy z grubą podeszwą.", stock: 10
    },
    {
        id: 5, name: "Adidas Superstar", brand: "Adidas", category: "damskie", type: "sportowe",
        price: 429.00, image: "https://via.placeholder.com/400x300/000000/ffffff?text=Adidas+Superstar",
        colors: ["biały", "czarny"], sizes: [36, 37, 38, 39], description: "Shell toe sneakersy z klasycznym designem.", stock: 14
    },
    {
        id: 6, name: "New Balance 327", brand: "New Balance", category: "damskie", type: "sportowe",
        price: 499.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=NB+327",
        colors: ["czerwony", "biały"], sizes: [37, 38, 39, 40], description: "Lifestyle sneakersy z retro designem.", stock: 11
    },
    {
        id: 7, name: "Nike Dunk Low", brand: "Nike", category: "damskie", type: "sportowe",
        price: 519.99, image: "https://via.placeholder.com/400x300/fdbcb4/000000?text=Nike+Dunk+Low",
        colors: ["beżowy", "biały"], sizes: [36, 37, 38, 39], description: "Basketball sneakersy w damskiej kolorystyce.", stock: 9
    },
    {
        id: 8, name: "Puma Mayze", brand: "Puma", category: "damskie", type: "sportowe",
        price: 389.99, image: "https://via.placeholder.com/400x300/9b59b6/ffffff?text=Puma+Mayze",
        colors: ["fioletowy", "biały"], sizes: [37, 38, 39], description: "Chunky sneakersy z grubą podeszwą.", stock: 13
    },
    {
        id: 9, name: "Adidas Gazelle", brand: "Adidas", category: "damskie", type: "sportowe",
        price: 419.99, image: "https://via.placeholder.com/400x300/27ae60/ffffff?text=Adidas+Gazelle",
        colors: ["zielony", "biały"], sizes: [36, 37, 38], description: "Suede sneakersy z lat 60.", stock: 16
    },
    {
        id: 10, name: "New Balance 550", brand: "New Balance", category: "damskie", type: "sportowe",
        price: 469.99, image: "https://via.placeholder.com/400x300/3498db/ffffff?text=NB+550",
        colors: ["niebieski", "biały"], sizes: [37, 38, 39], description: "Basketball sneakersy retro.", stock: 8
    },
    {
        id: 11, name: "Nike Blazer Mid", brand: "Nike", category: "damskie", type: "sportowe",
        price: 459.99, image: "https://via.placeholder.com/400x300/2c3e50/ffffff?text=Nike+Blazer",
        colors: ["granatowy", "biały"], sizes: [36, 37, 38, 39], description: "Vintage sneakersy zamszowe.", stock: 12
    },
    {
        id: 12, name: "Puma Palermo", brand: "Puma", category: "damskie", type: "sportowe",
        price: 369.99, image: "https://via.placeholder.com/400x300/e67e22/ffffff?text=Puma+Palermo",
        colors: ["pomarańczowy", "biały"], sizes: [37, 38], description: "Retro sneakersy terrace.", stock: 17
    },
    {
        id: 13, name: "Adidas Samba", brand: "Adidas", category: "damskie", type: "sportowe",
        price: 439.99, image: "https://via.placeholder.com/400x300/8e44ad/ffffff?text=Adidas+Samba",
        colors: ["fioletowy", "biały"], sizes: [36, 37, 38, 39], description: "Klasyczne indoor sneakersy.", stock: 10
    },
    {
        id: 14, name: "New Balance 990v5", brand: "New Balance", category: "damskie", type: "sportowe",
        price: 699.99, image: "https://via.placeholder.com/400x300/1abc9c/ffffff?text=NB+990v5",
        colors: ["szary", "biały"], sizes: [37, 38, 39], description: "Premium sneakersy z FuelCell.", stock: 7
    },
    {
        id: 15, name: "Nike Air Max 90", brand: "Nike", category: "damskie", type: "sportowe",
        price: 529.99, image: "https://via.placeholder.com/400x300/34495e/ffffff?text=Nike+Air+Max+90",
        colors: ["niebieski", "biały"], sizes: [36, 37, 38], description: "Ikoniczne Air Max z widoczną poduszką.", stock: 14
    },
    {
        id: 16, name: "Puma Suede Classic", brand: "Puma", category: "damskie", type: "sportowe",
        price: 349.99, image: "https://via.placeholder.com/400x300/9b59b6/ffffff?text=Puma+Suede",
        colors: ["bordowy", "biały"], sizes: [37, 38, 39], description: "Klasyczne sneakersy zamszowe.", stock: 11
    },
    {
        id: 17, name: "Adidas NMD", brand: "Adidas", category: "damskie", type: "sportowe",
        price: 599.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=Adidas+NMD",
        colors: ["czerwony", "biały"], sizes: [36, 37, 38], description: "Boost sneakersy lifestyle.", stock: 9
    },
    {
        id: 18, name: "New Balance Fresh Foam", brand: "New Balance", category: "damskie", type: "sportowe",
        price: 549.99, image: "https://via.placeholder.com/400x300/f39c12/ffffff?text=NB+Fresh+Foam",
        colors: ["pomarańczowy"], sizes: [37, 38, 39, 40], description: "Biegowe sneakersy z pianką Fresh Foam.", stock: 13
    },
    {
        id: 19, name: "Nike React Infinity", brand: "Nike", category: "damskie", type: "sportowe",
        price: 599.00, image: "https://via.placeholder.com/400x300/00d2d3/ffffff?text=Nike+React",
        colors: ["turkusowy"], sizes: [36, 37, 38], description: "Pianka React dla amortyzacji.", stock: 6
    },
    {
        id: 20, name: "Puma RS-X", brand: "Puma", category: "damskie", type: "sportowe",
        price: 499.99, image: "https://via.placeholder.com/400x300/95a5a6/ffffff?text=Puma+RS-X",
        colors: ["szary", "biały"], sizes: [37, 38, 39], description: "RS technology chunky sneakers.", stock: 15
    },


    {
        id: 21, name: "Adidas Ultraboost 22", brand: "Adidas", category: "męskie", type: "biegowe",
        price: 699.99, image: "https://via.placeholder.com/400x300/00b894/ffffff?text=Ultraboost+22",
        colors: ["czarny", "niebieski"], sizes: [41, 42, 43, 44, 45], description: "Biegowe z technologią Boost.", stock: 10
    },
    {
        id: 22, name: "New Balance 1080v13", brand: "New Balance", category: "męskie", type: "biegowe",
        price: 749.99, image: "https://via.placeholder.com/400x300/2980b9/ffffff?text=NB+1080v13",
        colors: ["granatowy"], sizes: [42, 43, 44, 45], description: "Flagowy model biegowy Fresh Foam.", stock: 8
    },
    {
        id: 23, name: "Nike Air Zoom Pegasus", brand: "Nike", category: "męskie", type: "biegowe",
        price: 599.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=Nike+Pegasus",
        colors: ["pomarańczowy"], sizes: [41, 42, 43, 44], description: "Zoom Air dla dynamicznego biegu.", stock: 12
    },
    {
        id: 24, name: "Puma Future Z", brand: "Puma", category: "męskie", type: "piłkarskie",
        price: 449.99, image: "https://via.placeholder.com/400x300/27ae60/ffffff?text=Puma+Future+Z",
        colors: ["zielony"], sizes: [42, 43, 44, 45], description: "Piłkarskie korki z NETFIT.", stock: 9
    },
    {
        id: 25, name: "Adidas Predator Freak", brand: "Adidas", category: "męskie", type: "piłkarskie",
        price: 599.99, image: "https://via.placeholder.com/400x300/c0392b/ffffff?text=Predator+Freak",
        colors: ["czerwony"], sizes: [41, 42, 43, 44], description: "Korki z strefami kontroli piłki.", stock: 11
    },
    {
        id: 26, name: "Nike Mercurial Vapor", brand: "Nike", category: "męskie", type: "piłkarskie",
        price: 649.99, image: "https://via.placeholder.com/400x300/f39c12/ffffff?text=Mercurial+Vapor",
        colors: ["pomarańczowy"], sizes: [42, 43, 44, 45], description: "Najszybsze korki Nike.", stock: 7
    },
    {
        id: 27, name: "New Balance Tekela V4", brand: "New Balance", category: "męskie", type: "piłkarskie",
        price: 499.99, image: "https://via.placeholder.com/400x300/8e44ad/ffffff?text=NB+Tekela",
        colors: ["fioletowy"], sizes: [41, 42, 43], description: "Korki z Hypoknit cholewką.", stock: 13
    },
        {
        id: 28, name: "Adidas Forum Low", brand: "Adidas", category: "męskie", type: "sportowe",
        price: 429.99, image: "https://via.placeholder.com/400x300/ffffff/000000?text=Adidas+Forum+Low",
        colors: ["biały", "czarny"], sizes: [41, 42, 43, 44], description: "Klasyczne sneakersy z niską cholewką.", stock: 12
    },
    {
        id: 29, name: "New Balance 530", brand: "New Balance", category: "męskie", type: "sportowe",
        price: 459.99, image: "https://via.placeholder.com/400x300/4a90e2/ffffff?text=NB+530",
        colors: ["szary", "biały"], sizes: [42, 43, 44, 45], description: "Retro sneakersy z amortyzacją.", stock: 10
    },
    {
        id: 30, name: "Nike Air Max Graviton", brand: "Nike", category: "męskie", type: "sportowe",
        price: 499.99, image: "https://via.placeholder.com/400x300/f7f7f7/000000?text=Nike+Graviton",
        colors: ["niebieski", "czarny"], sizes: [41, 42, 43], description: "Sneakersy z poduszką Air Max.", stock: 14
    },
    {
        id: 31, name: "Puma Velocity Nitro 2", brand: "Puma", category: "męskie", type: "biegowe",
        price: 549.99, image: "https://via.placeholder.com/400x300/ff6b6b/ffffff?text=Puma+Velocity+Nitro",
        colors: ["pomarańczowy", "czarny"], sizes: [42, 43, 44], description: "Biegowe z technologią Nitro.", stock: 11
    },
    {
        id: 32, name: "New Balance U9060", brand: "New Balance", category: "męskie", type: "sportowe",
        price: 599.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=NB+U9060",
        colors: ["zielony", "szary"], sizes: [41, 42, 43, 44], description: "Futurystyczne sneakersy lifestyle.", stock: 9
    },
    {
        id: 33, name: "Adidas Breaknet 2.0", brand: "Adidas", category: "męskie", type: "sportowe",
        price: 379.99, image: "https://via.placeholder.com/400x300/000000/ffffff?text=Adidas+Breaknet",
        colors: ["biały", "granatowy"], sizes: [42, 43, 44, 45], description: "Lekkie sneakersy codzienne.", stock: 15
    },
    {
        id: 34, name: "Nike Pegasus Trail", brand: "Nike", category: "męskie", type: "biegowe",
        price: 579.99, image: "https://via.placeholder.com/400x300/fdbcb4/000000?text=Nike+Pegasus+Trail",
        colors: ["czarny", "pomarańczowy"], sizes: [41, 42, 43], description: "Biegowe terenowe z Zoom Air.", stock: 8
    },
    {
        id: 35, name: "Puma Future Z 4", brand: "Puma", category: "męskie", type: "piłkarskie",
        price: 599.99, image: "https://via.placeholder.com/400x300/27ae60/ffffff?text=Puma+Future+Z4",
        colors: ["zielony", "biały"], sizes: [42, 43, 44, 45], description: "Korki z NETFIT dla kontroli.", stock: 10
    },
    {
        id: 36, name: "Adidas F50 Elite", brand: "Adidas", category: "męskie", type: "piłkarskie",
        price: 649.99, image: "https://via.placeholder.com/400x300/c0392b/ffffff?text=Adidas+F50+Elite",
        colors: ["czerwony"], sizes: [41, 42, 43, 44], description: "Szybkie korki na murawę.", stock: 7
    },
    {
        id: 37, name: "New Balance Fresh Foam 520", brand: "New Balance", category: "męskie", type: "biegowe",
        price: 499.99, image: "https://via.placeholder.com/400x300/3498db/ffffff?text=NB+Fresh+Foam+520",
        colors: ["niebieski"], sizes: [42, 43, 44], description: "Lekkie biegowe z pianką Fresh Foam.", stock: 13
    },
    {
        id: 38, name: "Nike Blazer Mid 77", brand: "Nike", category: "męskie", type: "sportowe",
        price: 469.99, image: "https://via.placeholder.com/400x300/2c3e50/ffffff?text=Nike+Blazer+77",
        colors: ["biały", "granatowy"], sizes: [41, 42, 43, 44], description: "Vintage sneakersy zamszowe.", stock: 12
    },
    {
        id: 39, name: "Puma RS-X3", brand: "Puma", category: "męskie", type: "sportowe",
        price: 519.99, image: "https://via.placeholder.com/400x300/95a5a6/ffffff?text=Puma+RS-X3",
        colors: ["szary"], sizes: [42, 43, 44, 45], description: "Chunky sneakersy z RS tech.", stock: 11
    },
    {
        id: 40, name: "Adidas Grand Court 2.0", brand: "Adidas", category: "męskie", type: "sportowe",
        price: 399.99, image: "https://via.placeholder.com/400x300/8e44ad/ffffff?text=Adidas+Grand+Court",
        colors: ["biały", "czarny"], sizes: [41, 42, 43], description: "Klasyczne tenisowe sneakersy.", stock: 16
    },
    {
        id: 41, name: "New Balance 410v9", brand: "New Balance", category: "męskie", type: "biegowe",
        price: 429.99, image: "https://via.placeholder.com/400x300/f39c12/ffffff?text=NB+410v9",
        colors: ["granatowy"], sizes: [42, 43, 44, 45], description: "Wszechstronne biegowe sneakersy.", stock: 9
    },
    {
        id: 42, name: "Adidas Runfalcon 5", brand: "Adidas", category: "dziecięce", type: "sportowe",
        price: 199.99, image: "https://via.placeholder.com/400x300/00b894/ffffff?text=Adidas+Runfalcon+Kids",
        colors: ["niebieski", "biały"], sizes: [28, 29, 30, 31, 32], description: "Lekkie sneakersy na co dzień.", stock: 20
    },
    {
        id: 43, name: "Nike Air Max Scorpion", brand: "Nike", category: "dziecięce", type: "sportowe",
        price: 249.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=Nike+Scorpion+Kids",
        colors: ["czerwony"], sizes: [29, 30, 31, 32, 33], description: "Sneakersy z widoczną poduszką Air.", stock: 18
    },
    {
        id: 44, name: "New Balance PV574", brand: "New Balance", category: "dziecięce", type: "sportowe",
        price: 229.99, image: "https://via.placeholder.com/400x300/4a90e2/ffffff?text=NB+PV574+Kids",
        colors: ["fioletowy"], sizes: [28, 29, 30, 31], description: "Retro sneakersy dla dziewczynek.", stock: 15
    },
    {
        id: 45, name: "Puma Rebound", brand: "Puma", category: "dziecięce", type: "sportowe",
        price: 189.99, image: "https://via.placeholder.com/400x300/ff6b6b/ffffff?text=Puma+Rebound+Kids",
        colors: ["różowy", "biały"], sizes: [30, 31, 32, 33], description: "Elastyczne sneakersy codzienne.", stock: 22
    },
    {
        id: 47, name: "Nike Dynamo Free", brand: "Nike", category: "dziecięce", type: "biegowe",
        price: 219.99, image: "https://via.placeholder.com/400x300/fdbcb4/000000?text=Nike+Dynamo+Kids",
        colors: ["beżowy"], sizes: [29, 30, 31, 32], description: "Elastyczne buty do biegania.", stock: 17
    },
    {
        id: 48, name: "New Balance PC1906", brand: "New Balance", category: "dziecięce", type: "sportowe",
        price: 239.99, image: "https://via.placeholder.com/400x300/e74c3c/ffffff?text=NB+PC1906+Kids",
        colors: ["różowy"], sizes: [28, 29, 30, 31, 32], description: "Kolorystyczne sneakersy dla dziewczynek.", stock: 14
    },
    {
        id: 49, name: "Puma Flexfocus Lite", brand: "Puma", category: "dziecięce", type: "biegowe",
        price: 209.99, image: "https://via.placeholder.com/400x300/9b59b6/ffffff?text=Puma+Flexfocus+Kids",
        colors: ["niebieski"], sizes: [30, 31, 32, 33, 34], description: "Lekkie biegowe sneakersy.", stock: 19
    },
    {
        id: 50, name: "Adidas Runfalcon 6", brand: "Adidas", category: "dziecięce", type: "sportowe",
        price: 199.99, image: "https://via.placeholder.com/400x300/27ae60/ffffff?text=Adidas+Runfalcon6+Kids",
        colors: ["zielony"], sizes: [27, 28, 29], description: "Sportowe z siatki dla dzieci.", stock: 21
    },
    {
        id: 51, name: "Nike Team Hustle", brand: "Nike", category: "dziecięce", type: "sportowe",
        price: 169.99, image: "https://via.placeholder.com/400x300/34495e/ffffff?text=Nike+Hustle+Kids",
        colors: ["granatowy"], sizes: [28, 29, 30, 31], description: "Wielofunkcyjne sneakersy halowe.", stock: 23
    },
    {
        id: 52, name: "New Balance PZ530", brand: "New Balance", category: "dziecięce", type: "sportowe",
        price: 249.99, image: "https://via.placeholder.com/400x300/1abc9c/ffffff?text=NB+PZ530+Kids",
        colors: ["biały"], sizes: [29, 30, 31, 32, 33], description: "Klasyczne białe sneakersy.", stock: 16
    },
    {
        id: 53, name: "Puma Suede Junior", brand: "Puma", category: "dziecięce", type: "sportowe",
        price: 189.99, image: "https://via.placeholder.com/400x300/9b59b6/ffffff?text=Puma+Suede+Kids",
        colors: ["bordowy"], sizes: [30, 31, 32], description: "Zamszowe sneakersy retro.", stock: 20
    },
    {
        id: 54, name: "Adidas X-Speedportal", brand: "Adidas", category: "dziecięce", type: "piłkarskie",
        price: 279.99, image: "https://via.placeholder.com/400x300/00d2d3/ffffff?text=Adidas+X-Speed+Kids",
        colors: ["turkusowy"], sizes: [28, 29, 30, 31], description: "Korki dla młodych piłkarzy.", stock: 12
    },
    {
        id: 55, name: "Nike Mercurial Academy", brand: "Nike", category: "dziecięce", type: "piłkarskie",
        price: 299.99, image: "https://via.placeholder.com/400x300/f39c12/ffffff?text=Nike+Mercurial+Kids",
        colors: ["pomarańczowy"], sizes: [29, 30, 31, 32], description: "Lekkie korki na murawę.", stock: 11
    },
    {
        id: 56, name: "New Balance Tekela Kids", brand: "New Balance", category: "dziecięce", type: "piłkarskie",
        price: 259.99, image: "https://via.placeholder.com/400x300/8e44ad/ffffff?text=NB+Tekela+Kids",
        colors: ["fioletowy"], sizes: [30, 31, 32, 33], description: "Piłkarskie z Hypoknit.", stock: 13
    },
    {
        id: 57, name: "Puma Future Match", brand: "Puma", category: "dziecięce", type: "piłkarskie",
        price: 269.99, image: "https://via.placeholder.com/400x300/e67e22/ffffff?text=Puma+Future+Kids",
        colors: ["pomarańczowy"], sizes: [28, 29, 30], description: "Korki z dobrą przyczepnością.", stock: 15
    },
    {
        id: 58, name: "Adidas Response Super", brand: "Adidas", category: "dziecięce", type: "biegowe",
        price: 219.99, image: "https://via.placeholder.com/400x300/95a5a6/ffffff?text=Adidas+Response+Kids",
        colors: ["szary"], sizes: [31, 32, 33, 34], description: "Biegowe z amortyzacją.", stock: 17
    },
    {
        id: 59, name: "Nike Flex Runner", brand: "Nike", category: "dziecięce", type: "biegowe",
        price: 199.99, image: "https://via.placeholder.com/400x300/34495e/ffffff?text=Nike+Flex+Kids",
        colors: ["niebieski"], sizes: [27, 28, 29, 30], description: "Elastyczne do aktywności.", stock: 24
    },
    {
        id: 60, name: "New Balance 515 Kids", brand: "New Balance", category: "dziecięce", type: "sportowe",
        price: 229.99, image: "https://via.placeholder.com/400x300/2980b9/ffffff?text=NB+515+Kids",
        colors: ["granatowy"], sizes: [29, 30, 31], description: "Minimalistyczne sneakersy.", stock: 18
    },
    {
        id: 61, name: "Puma Anzarun Lite", brand: "Puma", category: "dziecięce", type: "biegowe",
        price: 189.99, image: "https://via.placeholder.com/400x300/00b894/ffffff?text=Puma+Anzarun+Kids",
        colors: ["czarny"], sizes: [30, 31, 32, 33], description: "Lekkie biegowe na co dzień.", stock: 20
    }
]
