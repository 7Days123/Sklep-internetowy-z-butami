

document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.products-section')) {
        initProductsPage();
    }
});

function initProductsPage() {
    renderProducts(products, 'all');
    
    // filtry
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            
            const category = e.target.dataset.category;
            renderProducts(products, category);
        });
    });
}

function renderProducts(productsList, category) {
    const grid = document.getElementById('products-grid');
    const filtered = category === 'all' 
        ? productsList 
        : productsList.filter(p => p.category === category);

    grid.innerHTML = filtered.map(product => `
        <article class="product-card" data-product-id="${product.id}">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <div class="product-category">${product.category}</div>
                <h3 class="product-name">${product.name}</h3>
                <div class="product-brand">${product.brand}</div>
                <div class="product-price">${product.price.toLocaleString('pl-PL', { 
                    style: 'currency', 
                    currency: 'PLN' 
                })}</div>
            </div>
        </article>
    `).join('');

    // obsługa kliknięcia produktu
    document.querySelectorAll('.product-card').forEach(card => {
        card.addEventListener('click', () => {
            const id = card.dataset.productId;
            window.location.href = `product.html?id=${id}`;
        });
        // WYSZUKIWANIE
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');

if (searchInput) {
    let searchTimeout;
    
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            performSearch(e.target.value.toLowerCase());
        }, 300); 
    });
    
    searchBtn.addEventListener('click', () => {
        performSearch(searchInput.value.toLowerCase());
    });
    
    // enter
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            performSearch(e.target.value.toLowerCase());
        }
    });
}

function performSearch(query) {
    if (!query.trim()) {
        renderProducts(products, getCurrentCategory());
        return;
    }
    
    const filtered = products.filter(product => 
        product.name.toLowerCase().includes(query) ||
        product.brand.toLowerCase().includes(query) ||
        product.category.toLowerCase().includes(query)
    );
    
    renderProducts(filtered, 'search');
}

        
    });

    cart.updateCartCount();
}
// Zmienne globalne dla autentykacji
let currentUser = null;

// Otwórz modal
function openAuthModal() {
  document.getElementById('authModal').style.display = 'block';
}

// Zamknij modal
document.querySelector('.close').onclick = function() {
  document.getElementById('authModal').style.display = 'none';
  clearForms();
};

// Zamknij przy kliknięciu poza modalem
window.onclick = function(event) {
  const modal = document.getElementById('authModal');
  if (event.target == modal) {
    modal.style.display = 'none';
    clearForms();
  }
};

// Przełączanie tabów
function switchTab(tab) {
  // Usuń active z tabów i form
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.auth-form').forEach(form => form.classList.remove('active'));
  
  // Dodaj active do wybranego
  event.target.classList.add('active');
  document.getElementById(tab + 'Form').classList.add('active');
  
  clearForms(); // Wyczyść błędy przy przełączaniu
}

// Wyczyść formularze
function clearForms() {
  document.querySelectorAll('.error').forEach(el => el.textContent = '');
  document.querySelectorAll('input').forEach(input => input.value = '');
}

// Obsługa logowania
document.getElementById('loginForm').onsubmit = function(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  const errorEl = document.getElementById('loginError');
  
  // Symulacja walidacji (w realnej apce tu byłby fetch do API)
  if (email === 'test@example.com' && password === '123456') {
    currentUser = { email, name: 'Test User' };
    document.getElementById('authModal').style.display = 'none';
    updateHeaderUser();
    alert('Zalogowano pomyślnie!');
  } else {
    errorEl.textContent = 'Nieprawidłowy email lub hasło';
  }
};

// Obsługa rejestracji
document.getElementById('registerForm').onsubmit = function(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  const confirmPassword = document.getElementById('regConfirmPassword').value;
  const errorEl = document.getElementById('regError');
  
  if (password.length < 6) {
    errorEl.textContent = 'Hasło musi mieć min. 6 znaków';
    return;
  }
  
  if (password !== confirmPassword) {
    errorEl.textContent = 'Hasła nie pasują';
    return;
  }
  
  // Symulacja rejestracji
  currentUser = { name, email };
  document.getElementById('authModal').style.display = 'none';
  updateHeaderUser();
  alert(`Konto ${name} zostało utworzone!`);
};

// Aktualizuj header po logowaniu
function updateHeaderUser() {
  const loginBtn = document.querySelector('.login-btn');
  if (currentUser) {
    loginBtn.textContent = `Witaj, ${currentUser.name}!`;
    loginBtn.onclick = logout;
  }
}

// Wyloguj
function logout() {
  currentUser = null;
  document.querySelector('.login-btn').textContent = 'Zaloguj/Rejestruj';
  document.querySelector('.login-btn').onclick = openAuthModal;
}
